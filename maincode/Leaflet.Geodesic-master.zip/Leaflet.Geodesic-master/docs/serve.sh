#!/bin/bash

# This creates a webserver within the current folder. Used for local testing.
python3 -m http.server 8082